# 달씀 1.1.0

달력에 기록하는 개인용 원화 지출 가계부입니다. Android 8.0(API 26) 이상에서 설치하도록 빌드했습니다. Java Activity 안에서 앱에 포함된 HTML/CSS/JavaScript 화면을 실행합니다. 외부 서버, 광고, 로그인, 카드사 연동은 없습니다.

## 제공 기능

- 달력 날짜 칸에는 일자, 지출 건수, 합계 금액만 표시합니다.
- 날짜를 누르면 해당 날짜의 내역으로 이동합니다. `지출 입력`에서 금액을 직접 입력하고 용도·카드는 목록에서 고릅니다.
- 내역을 누르면 날짜·금액·용도·카드·선택 메모를 수정하거나 지출을 삭제할 수 있습니다.
- 월별 조회에서 용도와 카드를 각각 또는 동시에 필터링하고, 용도별·카드별 합계를 봅니다.
- 카드별 기준 금액을 설정합니다. 합계가 기준 미만이면 초록, 기준 이상이면 빨강입니다. 색상과 함께 도달 여부 문구도 표시합니다. 0원은 기준 알림 끄기입니다.
- 설정에서 용도와 카드를 추가·이름 변경·삭제합니다. 기록에 사용 중인 항목은 삭제를 막습니다.
- 기기 내부 저장과 JSON 파일 백업·복원. 복원 시 형식을 검증하고 교체 여부를 확인합니다.

## 계산 기준

입력한 **지출일의 달력 월**을 기준으로 합산합니다. 실제 카드 결제일별 청구액이나 카드사의 전월 실적 조건은 반영하지 않습니다. 같은 카드사의 합계를 확인하려면 하나의 카드 항목에 모아 입력하세요. 알림은 **앱 내부 아이콘**으로 표시되며 푸시 알림은 없습니다. 초기 카드 기준은 각 300,000원이며 설정에서 바꿀 수 있습니다.

지출은 1~999,999,999,999원, 기준 금액은 0~999,999,999,999원, 날짜는 1900~2199년을 지원합니다. 카테고리·카드는 각 100개, 지출은 50,000건까지입니다. 합계는 JavaScript 안전 정수 범위 안에서만 저장합니다.

## 저장과 백업

Android에서는 SharedPreferences의 앱 전용 영역에 저장합니다. 인터넷 권한과 저장소 전체 접근 권한을 요청하지 않습니다. 백업 파일 위치는 Android의 파일 선택기에서 직접 고릅니다. JSON 백업은 암호화되지 않았습니다. 앱 삭제나 기기 변경 전에 백업하세요. 복원은 현재 내역 전체를 교체하므로 현재 기록을 먼저 백업하는 편이 좋습니다. 예시 이미지는 가상 데이터이며 APK에는 예시 거래가 포함되지 않습니다.

## APK 빌드

JDK 21, Android SDK Build Tools 35.0.0, Android API 35의 android.jar를 준비한 다음 PowerShell에서 실행합니다. Gradle 및 외부 앱 라이브러리는 사용하지 않습니다.

```powershell
./build.ps1 -JavaHome 'C:/tools/jdk-21' -BuildTools 'C:/Android/sdk/build-tools/35.0.0' -AndroidJar 'C:/Android/sdk/platforms/android-35/android.jar'
```

결과는 `build/dalsseum-1.1.0.apk`입니다. 업데이트 APK를 만들 때는 AndroidManifest.xml의 versionCode와 versionName을 올리고 동일한 서명 키를 유지해야 기존 설치 위에 업데이트할 수 있습니다.

## 서명 키 보관

소스 압축 파일에는 이 APK에 사용한 `dalsseum-signing.p12`가 포함됩니다. alias는 `dalsseum`, 저장소·키 비밀번호는 빌드 스크립트의 `ANDROID_KEYSTORE_PASSWORD (set privately)`입니다. 소유자가 후속 업데이트를 만들 수 있도록 제공한 개인 배포용 키입니다. **소스 압축 파일과 키는 비공개로 보관하세요.** 공개 저장소에 올리기 전에는 키 파일과 비밀번호를 제거하세요. 이미 배포한 APK를 업데이트할 계획이라면 이 키의 별도 백업도 보관해야 합니다.

## 검증

Node.js와 Playwright로 모델·화면 동작 70개 검증을 통과했습니다. 검증 범위는 월 필터·합계, 기준 도달 경계값, 윤년, 입력 제한, 백업 스키마·잘못된 참조·중복 ID 거부, UI 입력·수정·삭제, 저장 유지, 용도·카드 조합 조회, 카드 설정, 복원 취소·확인, 손상된 저장 데이터 보호, 네이티브 백업 브리지 호출과 320/390/600px 가로 넘침 여부입니다. 브라우저 JavaScript 오류는 없었습니다. APK 메타데이터 및 v2/v3 서명 검증도 통과했습니다.

실제 Android 기기 또는 에뮬레이터에서 설치·WebView 실행·Android 파일 선택기의 저장·복원·시스템 뒤로가기 동작은 검증하지 못했습니다. 휴대폰에서 처음 사용하기 전 소액 지출 1건으로 저장과 백업·복원을 확인해 주세요.

테스트를 다시 실행하려면 Node.js 20 이상과 Playwright 1.62.1을 설치하고 `node test.cjs`를 실행하세요. 테스트는 기본 Chrome 설치 경로를 사용합니다. 필요하면 test.cjs의 executablePath를 변경하세요.

공식 빌드 도구: https://developer.android.com/studio#command-line-tools-only

## 1.1.0 변경

Android 11 이상의 시스템 키보드 영역을 FrameLayout에서 처리해 WebView의 실제 높이를 줄이고, 웹 입력 시 가용 viewport 높이에 맞춘 전체 입력 화면과 포커스 자동 스크롤을 적용했습니다. Android 13 이상의 OnBackInvokedDispatcher와 이전 onBackPressed를 함께 처리합니다.

지출 입력 중 용도·카드를 바로 추가하며 초안과 선택값을 유지합니다. 설정 화면에 로컬 저장 상태 확인을 넣고 저장 직후 읽기 검증을 추가했습니다.

version 1 JSON 형식을 유지하면서 선택 필드 monthlySettings를 추가했습니다. 이전 파일에서 이 필드가 없으면 빈 배열로 읽습니다. 각 항목은 {card, month, payment, limit}이며 payment=null은 미설정, limit=null은 카드 기본 알림 기준 사용, limit=0은 해당 월 알림 끄기입니다. 결제 예정 금액과 지출 합계는 서로 별도 값입니다. monthlySettings는 최대 12,000개입니다.

70개 검증에는 1.0.0 백업 마이그레이션, 월별 값 분리·복원, 항목 추가 시 초안 유지와 취소, 네이티브 브리지 저장 실패·읽기 검증, 390×360/640×260 viewport에서 입력칸 가시성과 웹 뒤로가기 분기가 추가됐습니다. 네이티브 SharedPreferences 실제 저장·Android 키보드·종료 확인창은 기기에서 실행하지 못했고, Java 컴파일과 소스·서명 검증 및 브라우저 기반 동작만 확인했습니다.

키보드 영역 처리에 참고한 공식 문서: https://developer.android.com/develop/ui/views/layout/webapps/understand-window-insets
뒤로가기 콜백 참고: https://developer.android.com/reference/android/window/OnBackInvokedDispatcher
