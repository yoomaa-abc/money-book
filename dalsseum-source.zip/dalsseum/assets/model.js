(function(root){
 'use strict';
 const MAX=999999999999;
 const defaults=()=>({version:1,categories:[{id:'food',name:'식비'},{id:'cafe',name:'카페·간식'},{id:'shop',name:'쇼핑'},{id:'traffic',name:'교통'},{id:'home',name:'생활'},{id:'health',name:'건강'},{id:'etc',name:'기타'}],cards:[{id:'shinhan',name:'신한카드',limit:300000},{id:'samsung',name:'삼성카드',limit:300000},{id:'hyundai',name:'현대카드',limit:300000}],entries:[]});
 function dateOK(s){if(typeof s!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(s))return false;const [y,m,d]=s.split('-').map(Number);return y>=1900&&y<=2199&&m>=1&&m<=12&&d>=1&&d<=new Date(y,m,0).getDate();}
 function moneyOK(v,zero=false){return Number.isSafeInteger(v)&&v>=(zero?0:1)&&v<=MAX;}
 function validate(s){
  if(!s||s.version!==1||!Array.isArray(s.categories)||!Array.isArray(s.cards)||!Array.isArray(s.entries)||s.entries.length>50000)throw Error('달씀 백업 파일 형식이 아니에요.');
  for(const key of ['categories','cards']){if(!s[key].length||s[key].length>100)throw Error('카테고리 개수를 확인해 주세요.');const ids=new Set(),names=new Set();s[key].forEach(x=>{if(!x||typeof x.id!=='string'||!(/^[a-zA-Z0-9_-]{1,100}$/).test(x.id)||ids.has(x.id)||typeof x.name!=='string'||!x.name.trim()||x.name.length>30||names.has(x.name.trim())||(key==='cards'&&!moneyOK(x.limit,true)))throw Error('카테고리 정보가 올바르지 않아요.');ids.add(x.id);names.add(x.name.trim());});}
  const ids=new Set();s.entries.forEach(e=>{if(!e||typeof e.id!=='string'||!(/^[a-zA-Z0-9_-]{1,100}$/).test(e.id)||ids.has(e.id)||!dateOK(e.date)||!moneyOK(e.amount)||!s.categories.some(c=>c.id===e.category)||!s.cards.some(c=>c.id===e.card)||typeof e.memo!=='string'||e.memo.length>100)throw Error('지출 내역이 올바르지 않아요.');ids.add(e.id);});
  const total=s.entries.reduce((a,e)=>a+e.amount,0);if(!Number.isSafeInteger(total))throw Error('총금액이 처리 범위를 초과했어요.');
  return {version:1,categories:s.categories.map(c=>({id:c.id,name:c.name.trim()})),cards:s.cards.map(c=>({id:c.id,name:c.name.trim(),limit:c.limit})),entries:s.entries.map(e=>({id:e.id,date:e.date,amount:e.amount,category:e.category,card:e.card,memo:e.memo}))};
 }
 function monthly(s,month,category='',card=''){return s.entries.filter(e=>e.date.slice(0,7)===month&&(!category||e.category===category)&&(!card||e.card===card)).sort((a,b)=>b.date.localeCompare(a.date)||b.id.localeCompare(a.id));}
 const total=es=>es.reduce((s,e)=>s+e.amount,0);
 function cardState(s,month,id){const c=s.cards.find(c=>c.id===id),sum=total(monthly(s,month,'',id));return {sum,limit:c.limit,reached:c.limit>0&&sum>=c.limit,ratio:c.limit>0?Math.min(1,sum/c.limit):0};}
 const api={defaults,validate,dateOK,moneyOK,monthly,total,cardState,MAX};
 if(typeof module!=='undefined')module.exports=api;else root.Ledger=api;
})(this);
