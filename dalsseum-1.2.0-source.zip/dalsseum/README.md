# 달씀 1.2.0

Android 8.0(API 26) 이상을 대상으로 만든 오프라인 지출 가계부입니다. Java Activity에서 앱에 포함한 HTML/CSS/JavaScript를 WebView로 실행합니다. 계정·외부 서버·광고·카드사 연동은 없습니다.

## 용도별 독립 달력

상단 선택창에서 집안·데이트·모임 등 달력을 골라 기록합니다. 달력마다 지출, 용도 목록, 카드 목록, 월별 카드 결제 예정 금액 및 알림 기준을 별도로 저장합니다. 일별·월별·카드별 조회에는 선택한 달력만 사용합니다. 이름 변경과 빈 달력 삭제를 지원하며 달력 개수에 별도 제한은 없습니다. 저장 용량과 메모리의 실제 한계는 있습니다. 달력별로 지출 최대 50,000건, 용도와 카드 각 100개, 월별 카드 설정 12,000개를 지원합니다.

저장 형식은 version 2의 `{version:2,activeCalendar,calendars:[{id,name,ledger}]}`입니다. 각 ledger는 이전 version 1 데이터 형식을 그대로 사용합니다. 이전 version 1 기록과 백업은 `집안 가계부` 달력으로 읽어 기록과 설정을 보존합니다. 앱 ID·Activity 이름·SharedPreferences 키·서명 키를 유지하여 기존 설치 위에 업데이트할 수 있도록 했습니다. 마지막 선택한 달력도 저장합니다.

백업은 전체 데이터베이스를 하나의 JSON으로 내보내고, 복원은 전체 달력을 교체합니다. 형식·참조·중복 등을 검증하고 확인창을 거칩니다. JSON은 암호화되지 않았습니다. 앱 삭제·데이터 삭제 전에 백업하세요.

## 계산 및 저장

지출 합계는 지출일이 속한 달의 합계입니다. 직접 입력하는 결제 예정 금액과 별도이며, 실제 카드 청구 주기나 실적과 자동 연동되지 않습니다. 입력한 지출 합계가 알림 기준 이상일 때 앱 내부 아이콘이 빨강으로 변합니다. 알림 기준 빈칸은 카드 기본값, 0은 해당 월 알림 끄기입니다.

Android의 앱 전용 SharedPreferences에 저장한 뒤 읽기 검증을 수행합니다. 화면의 저장 상태 확인은 별도 임시 키로 쓰기·읽기를 점검합니다. 월별 집계를 한 번 계산해 재사용하고 일별/월별 내역은 50건 단위 페이지로 표시합니다. 키보드 영역 처리, 입력 포커스 스크롤, Android 13 이상의 뒤로가기 콜백과 이전 onBackPressed 처리를 포함합니다.

## 빌드

JDK 21, Android SDK Build Tools 35.0.0, Android API 35의 android.jar가 필요합니다. Gradle과 외부 앱 라이브러리는 사용하지 않습니다.

```powershell
./build.ps1 -JavaHome 'C:/tools/jdk-21' -BuildTools 'C:/Android/sdk/build-tools/35.0.0' -AndroidJar 'C:/Android/sdk/platforms/android-35/android.jar'
```

결과는 `build/dalsseum-1.2.0.apk`입니다. 업데이트 때는 versionCode를 올리고 동일한 서명 키를 유지하세요.

## 서명 키

서명 개인키와 기존 비밀번호는 GitHub 업로드에서 제외했습니다. 기존 앱 업데이트에는 원본 개인키를 별도로 안전하게 보관해야 합니다. 빌드 스크립트의 비밀번호는 `ANDROID_KEYSTORE_PASSWORD` 환경변수로 지정하세요. 키를 새로 생성하면 기존 앱의 업데이트 서명과 달라집니다.


## 검증

Node.js 20 이상과 Playwright 1.62.1에서 다음을 실행합니다. 기본 Chrome 경로는 test 파일의 executablePath에서 변경할 수 있습니다. 예시 이미지 출력은 이 작업의 outputs 경로를 사용하므로 다른 환경에서는 screenshot 경로도 변경하세요.

```text
node test.cjs
node test-calendars.cjs
node benchmark.cjs
```

기존 테스트 70개, 다중 달력 테스트 48개를 통과했습니다. 이전 파일 마이그레이션, 동일 날짜·카드의 격리, 수정·삭제 격리, 카테고리·월별 설정 분리, 생성·이름 변경·중복 이름·안전한 삭제, 마지막 선택 유지, 전체 백업과 복원, 203개 달력 검증 및 작은 화면 너비를 포함합니다. Java 컴파일, APK 메타데이터와 v2/v3 서명을 확인했습니다. 실제 Android 기기·에뮬레이터에서 설치·키보드·네이티브 파일 선택기·종료 확인창은 실행 검증하지 못했습니다.

공식 빌드 도구: https://developer.android.com/studio#command-line-tools-only
